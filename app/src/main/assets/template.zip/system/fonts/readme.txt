本模块 system/fonts 文件夹里的 EmptyFont 为空字体，在 fonts.xml 等配置文件中首先调用，用于提供字重及度量信息，请勿删除。

The EmptyFont files in folder "system/fonts" are used to provide font weight and metric information and first invoked in fonts.xml and other font configuration XML files. Please do not delete them.
